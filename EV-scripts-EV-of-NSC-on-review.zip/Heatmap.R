
setwd("C:\\Users\\AlianWang\\Desktop")     
rt=read.table("geneSigExp.txt",sep="\t",header=T,row.names=1,check.names=F)
library(pheatmap)
Type=c(rep("N",5),rep("T",5))  
names(Type)=colnames(rt)
Type=as.data.frame(Type)
pdf("heatmap.pdf",height=5,width=8)
pheatmap(rt, 
         annotation=Type,
         cluster_cols =F,cluster_rows =F,
         show_colnames = F,
         scale="row",
         fontsize = 10,
         fontsize_row=10,
         fontsize_col=3)
dev.off()
