library("clusterProfiler")
library("org.Hs.eg.db")
library("org.Mm.eg.db")
library("enrichplot")
library("ggplot2")
setwd("C:\\Users\\AlianWang\\Desktop")        
rt=read.table("input.txt",sep="\t",header=T,check.names=F)       
rt=rt[is.na(rt[,"entrezID"])==F,]                             
gene=rt$entrezID

#Mouse
allkk <- enrichKEGG(gene = gene, organism = "mmu", pvalueCutoff =1, qvalueCutoff =1)   
write.table(allkk,file="KEGG-all.txt",sep="\t",quote=F,row.names = F)                          
allgokk <- enrichGO(gene = gene,
                    OrgDb = org.Mm.eg.db, 
                    pvalueCutoff =1, 
                    qvalueCutoff = 1,
                    ont="all",
                    readable =T)  
write.table(allgokk,file="GO-all.txt",sep="\t",quote=F,row.names = F)  

#Human
allkk <- enrichKEGG(gene = gene, organism = "hsa", pvalueCutoff =1, qvalueCutoff =1)   
write.table(allkk,file="KEGG-all.txt",sep="\t",quote=F,row.names = F)                          
allgokk <- enrichGO(gene = gene,
                    OrgDb = org.Hs.eg.db, 
                    pvalueCutoff =1, 
                    qvalueCutoff = 1,
                    ont="all",
                    readable =T)  
write.table(allgokk,file="GO-all.txt",sep="\t",quote=F,row.names = F)  

